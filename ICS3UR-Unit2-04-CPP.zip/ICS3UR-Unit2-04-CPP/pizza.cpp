// Copyright (c) 2019 St. Mother Teresa HS All rights reserved.
//
// Created by Gabriel A
// Created on Nov 2020
// This program calculates the cost of pizza

#include <iostream>
#include <iomanip>

int main() {
    // this function calculates the cost of pizza
    const float labour = 0.75;
    const float rent = 1.00;
    const float cpi = 0.50;
    const float tax = 0.13;
    float diameter;
    float sub_total;
    float total;

    // input
    std::cout << "Enter the diameter of the pizza you would like (inch): ";
    std::cin >> diameter;

    // process
    sub_total = labour + rent + (diameter * cpi);
    total = sub_total + (sub_total * tax);

    // output
    std::cout << "" << std::endl;
    std::cout << "The cost for a " << diameter << " inch pizza is: $"
    << std::fixed << std::setprecision(2) << std::setfill('0') << total <<
    "." << std::endl;
}
